const { Client, GatewayIntentBits, SlashCommandBuilder, Routes, EmbedBuilder } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { token, clientId, guildId } = require('./config.json');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder()
    .setName('world')
    .setDescription('Select a WorldAfterEvent in Minecraft')
    .addStringOption(option =>
      option.setName('event')
        .setDescription('Choose the event you want')
        .setRequired(true)
        .addChoices(
          { name: 'entitySpawn', value: 'entitySpawn' },
          { name: 'entityRemove', value: 'entityRemove' },
          { name: 'playerJoin', value: 'playerJoin' },
          { name: 'playerLeave', value: 'playerLeave' },
          { name: 'explosion', value: 'explosion' },
          { name: 'gameRuleChange', value: 'gameRuleChange' },
          { name: 'itemUse', value: 'itemUse' },
          { name: 'playerInteractWithBlock', value: 'playerInteractWithBlock' },
          { name: 'weatherChange', value: 'weatherChange' },
          { name: 'entityDie', value: 'entityDie' },
        )),
]
  .map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log('Registering slash commands...');

    await rest.put(
      Routes.applicationGuildCommands(clientId, guildId),
      { body: commands },
    );

    console.log('Slash commands registered successfully!');
  } catch (error) {
    console.error(error);
  }
})();

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'world') {
    const selectedEvent = interaction.options.getString('event');

    const eventsData = {
      entitySpawn: {
        title: 'entitySpawn',
        description: 'This event triggers when an entity spawns in the world.',
        code: `world.afterEvents.entitySpawn.subscribe((event) => {
  world.sendMessage(\`Entity spawned: \${event.entity.typeId}\`);
});`,
      },
      entityRemove: {
        title: 'entityRemove',
        description: 'This event triggers when an entity is removed from the world.',
        code: `world.afterEvents.entityRemove.subscribe((event) => {
  world.sendMessage(\`Entity removed: \${event.typeId}\`);
});`,
      },
      playerJoin: {
        title: 'playerJoin',
        description: 'This event triggers when a player joins the world.',
        code: `world.afterEvents.playerJoin.subscribe((event) => {
  world.sendMessage(\`\${event.player.name} joined the game!\`);
});`,
      },
      playerLeave: {
        title: 'playerLeave',
        description: 'This event triggers when a player leaves the world.',
        code: `world.afterEvents.playerLeave.subscribe((event) => {
  world.sendMessage(\`\${event.player.name} left the game.\`);
});`,
      },
      explosion: {
        title: 'explosion',
        description: 'This event triggers after an explosion occurs in the world.',
        code: `world.afterEvents.explosion.subscribe((event) => {
  console.log(\`Explosion occurred in dimension: \${event.dimension.id}\`);
});`,
      },
      gameRuleChange: {
        title: 'gameRuleChange',
        description: 'This event triggers when a game rule is changed.',
        code: `world.afterEvents.gameRuleChange.subscribe((event) => {
  world.sendMessage(\`Game rule \${event.rule} updated to \${event.value}\`);
});`,
      },
      itemUse: {
        title: 'itemUse',
        description: 'This event triggers when a player uses an item.',
        code: `world.afterEvents.itemUse.subscribe((event) => {
  world.sendMessage(\`\${event.source.name} used item \${event.itemStack.typeId}\`);
});`,
      },
      playerInteractWithBlock: {
        title: 'playerInteractWithBlock',
        description: 'This event triggers when a player interacts with a block.',
        code: `world.afterEvents.playerInteractWithBlock.subscribe((event) => {
  const { source, block } = event;
  world.sendMessage(\`\${source.name} interacted with block at coordinates (\${block.location.x}, \${block.location.y}, \${block.location.z})\`);
});`,
      },
      weatherChange: {
        title: 'weatherChange',
        description: 'This event triggers when the weather changes in the world.',
        code: `world.afterEvents.weatherChange.subscribe((event) => {
  world.sendMessage(\`Weather changed to \${event.newWeather}\`);
});`,
      },
      entityDie: {
        title: 'entityDie',
        description: 'This event triggers when an entity dies in the world.',
        code: `world.afterEvents.entityDie.subscribe((event) => {
  world.sendMessage(\`Entity \${event.entity.typeId} died.\`);
});`,
      },
    };

    const eventInfo = eventsData[selectedEvent];

    if (!eventInfo) {
      await interaction.reply({ content: 'Unknown event.', ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🔹 ${eventInfo.title}`)
      .setDescription(eventInfo.description)
      .addFields({ name: '📄 Code Example', value: `\`\`\`javascript\n${eventInfo.code}\n\`\`\`` })
      .setColor(0x00AE86)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
});

client.login(token);